package com.example.doancuoiky.Activity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.doancuoiky.AsyncTask.AddDayPlanAsyncTask;
import com.example.doancuoiky.AsyncTask.UpdateDayplanSyncTask;
import com.example.doancuoiky.Model.Dayplan;
import com.example.doancuoiky.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class AddDayplanActivity extends AppCompatActivity {
    Spinner statusSpinner;
    EditText txtDate, txtNotes;
    Button btnCan, btnSave;
    ArrayAdapter<String> adapter;
    String[] statuses = {"not-started", "in-progress", "completed"};
    int GoalID;
    Dayplan dayplan;
    Date date;
    String statuss;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_dayplan);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        addControls();
        getIntentGoalID();
        getIntentDayPlans();
        addEvents();
    }

    private void addEvents() {
        txtDate.setOnClickListener(view -> showDatePickerDialog());
        btnCan.setOnClickListener(view -> finish());
        statusSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                statuss = statuses[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                try {

                    dayplan.setDate(dateFormat.parse(txtDate.getText().toString()));
                    if (dayplan.getId() == 0)
                        dayplan.setGoal_id(GoalID);
                    dayplan.setNotes(txtNotes.getText().toString());
                    dayplan.setProgress(0);
                    dayplan.setStatus(statuss);
                    if(dayplan.getId() == 0) {
                        if (date.compareTo(dayplan.getDate()) > 0) {
                            new AddDayPlanAsyncTask(AddDayplanActivity.this, dayplan).execute();
                        } else {
                            Toast.makeText(AddDayplanActivity.this, "Ngày không hợp lệ", Toast.LENGTH_SHORT).show();
                        }
                    }else{
                       new UpdateDayplanSyncTask(AddDayplanActivity.this,dayplan).execute();
                    }
                } catch (ParseException e) {
                    throw new RuntimeException(e);
                }


            }
        });
    }

    private void getIntentGoalID()
    {
        Intent intentAddDayplans = getIntent();
        if(intentAddDayplans.hasExtra("goalid"))
        {
            GoalID = intentAddDayplans.getIntExtra("goalid", -1);
            String dateString = intentAddDayplans.getStringExtra("targerdate");
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            try {
                date = dateFormat.parse(dateString);
            } catch (ParseException e) {
                throw new RuntimeException(e);
            }
        }
    }

    private void getIntentDayPlans()
    {
        Intent intentUpdateDayplan = getIntent();
        if(intentUpdateDayplan.hasExtra("dayplan"))
        {
            dayplan = (Dayplan) intentUpdateDayplan.getSerializableExtra("dayplan");
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String formattedDate = dateFormat.format(dayplan.getDate());
            txtDate.setText(formattedDate);
            txtNotes.setText(dayplan.getNotes());
            for (int i = 0; i < statuses.length; i++)
            {
                if(statuses[i].equals(dayplan.getStatus())) {
                    statusSpinner.setSelection(i);
                    break;
                }
            }
        }else{
            dayplan = new Dayplan();
        }
    }

    private void addControls() {
        statusSpinner = findViewById(R.id.statusSpinner);
        txtDate = findViewById(R.id.txtDateDayPlan);
        txtNotes = findViewById(R.id.txtNotes);
        btnCan = findViewById(R.id.btnCanDayPlan);
        btnSave = findViewById(R.id.btnSaveDayPlan);
        setSpinnerAdapter();
    }

    private void setSpinnerAdapter() {
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, statuses);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        statusSpinner.setAdapter(adapter);
    }
    private void showDatePickerDialog() {
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                (DatePicker view, int selectedYear, int selectedMonth, int selectedDay) -> {
                    String selectedDate = selectedYear + "-" + (selectedMonth + 1) + "-" + selectedDay;
                    txtDate.setText(selectedDate);
                },
                year, month, day
        );

        datePickerDialog.show();
    }
}