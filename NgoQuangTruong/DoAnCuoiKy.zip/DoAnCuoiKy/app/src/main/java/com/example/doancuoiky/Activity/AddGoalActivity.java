package com.example.doancuoiky.Activity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.doancuoiky.AsyncTask.AddGoalAsyncTask;
import com.example.doancuoiky.AsyncTask.UpdateGoalAsyncTask;
import com.example.doancuoiky.Model.Goal;
import com.example.doancuoiky.Model.User;
import com.example.doancuoiky.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class AddGoalActivity extends AppCompatActivity {
    EditText txtTargetDate,txtTitle, txtDescr;
    RadioButton rdoPri, rdoPub;
    Button btnSaveGoal;
    Spinner statusSpinner;
    ArrayAdapter<String> adapter;
    String[] statuses = {"not-started", "in-progress", "achieved"};
    String statuss = "not-started";
    int UserID;
    Goal goal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_goal);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        addControls();
        getInforUser();
        getIntentGoal();
        addEvents();
    }


    private void addEvents() {
        txtTargetDate.setOnClickListener(view -> showDatePickerDialog());
        statusSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                statuss = statuses[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        btnSaveGoal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goal.setUser_id(UserID);
                goal.setGoal_tittle(txtTitle.getText().toString());
                goal.setDescription(txtDescr.getText().toString());
                if(rdoPri.isChecked())
                {
                    goal.setVisibility(rdoPri.getText().toString());
                }else{
                    goal.setVisibility(rdoPub.getText().toString());
                }
                String targetDateString = txtTargetDate.getText().toString();
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                try {
                    Date targetDate = dateFormat.parse(targetDateString);
                    goal.setTarget_date(targetDate);
                    goal.setStatus(statuss);
                    goal.setProgess(0);
                    if(goal.getId() == 0)
                        new AddGoalAsyncTask(AddGoalActivity.this, goal).execute();
                    else {
                        new UpdateGoalAsyncTask(AddGoalActivity.this, goal).execute();
                    }
                } catch (ParseException e) {
                    throw new RuntimeException(e);
                }
            }
        });
    }


    private void addControls() {
        txtTargetDate = findViewById(R.id.txtTargetDate);
        statusSpinner = findViewById(R.id.statusSpinner);
        txtTitle = findViewById(R.id.txtGoalTitle);
        txtDescr = findViewById(R.id.txtDescription);
        rdoPri = findViewById(R.id.rdoPri);
        rdoPub = findViewById(R.id.rdoPub);
        btnSaveGoal = findViewById(R.id.btnSaveAddGoal);
        setSpinnerAdapter();
    }
    private void showDatePickerDialog() {
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                (DatePicker view, int selectedYear, int selectedMonth, int selectedDay) -> {
                    String selectedDate = selectedYear + "-" + (selectedMonth + 1) + "-" + selectedDay;
                    txtTargetDate.setText(selectedDate);
                },
                year, month, day
        );

        datePickerDialog.show();
    }

    private void setSpinnerAdapter()
    {
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, statuses);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        statusSpinner.setAdapter(adapter);
    }
    private void getInforUser() {
        SharedPreferences sharedPreferences = getSharedPreferences("UserSession", MODE_PRIVATE);

        String email = sharedPreferences.getString("Email", null);
        String userName = sharedPreferences.getString("Name", null);
        UserID = sharedPreferences.getInt("UserID", -1);
        boolean isLoggedIn = sharedPreferences.getBoolean("isLoggedIn", false);

        if(isLoggedIn){

        }else{
            Toast.makeText(this, "Người dùng chưa đăng nhập!", Toast.LENGTH_SHORT).show();
            UserID = -1;
        }
    }
    private void getIntentGoal()
    {
        Intent intentUpdate = getIntent();
        if(intentUpdate.hasExtra("goal"))
        {
            goal = (Goal) intentUpdate.getSerializableExtra("goal");
            txtTitle.setText(goal.getGoal_tittle());
            txtDescr.setText(goal.getDescription());
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String formattedDate = dateFormat.format(goal.getTarget_date());
            txtTargetDate.setText(formattedDate);
            if(goal.getVisibility().equals("private") ){
                rdoPri.setChecked(true);
            }else
                rdoPub.setChecked(true);
            for (int i =0 ; i < 3 ;i++)
            {
                if (statuses[i].equals(goal.getStatus()))
                {
                    statusSpinner.setSelection(i);
                    break;
                }
            }
        }else{
            goal = new Goal();
        }
    }
}