package com.example.doancuoiky.Activity;

import android.annotation.SuppressLint;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.doancuoiky.AsyncTask.AddTaskAsyncTask;
import com.example.doancuoiky.AsyncTask.UpdateTaskAsynTask;
import com.example.doancuoiky.Model.Task;
import com.example.doancuoiky.R;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;

public class AddTaskActivity extends AppCompatActivity {
EditText txtTitle, txtDescr, txtStartTime, txtEndTime;
TextView txtProgressValue;
Spinner spnPriority, spnStatus;
Button btnCan, btnSave;
SeekBar sbProgress;
String Priorities[] = {"low", "medium", "high"};
String Statusses[] = {"pending", "in-progress", "completed", "overdue"};
String Prioritiy;
String Statuss;
ArrayAdapter adapterPrio, adapterSta;
int dayplanid;
Task task;
double SumProgress = 0,progresstask;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_task);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        addControls();
        getIntentDayplanid();
        getInentTask();
        addEvents();
    }

    private void addEvents() {
        txtStartTime.setOnClickListener(view -> showTimePicker(txtStartTime));
        txtEndTime.setOnClickListener(view -> showTimePicker(txtEndTime));
        sbProgress.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // Cập nhật TextView với giá trị hiện tại
                txtProgressValue.setText(progress + "%");
                progresstask = progress;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // Không cần xử lý
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // Không cần xử lý
            }
        });
        btnCan.setOnClickListener(view -> finish());
        spnPriority.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                Prioritiy = Priorities[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        spnStatus.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                Statuss = Statusses[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(task.getId() == 0)
                    task.setDayplan_id(dayplanid);
                task.setDescription(txtDescr.getText().toString());
                task.setTittle(txtTitle.getText().toString());
                task.setPriority(Prioritiy);
                task.setStatus(Statuss);
                task.setProgress(progresstask);
                task.setStarttime(txtStartTime.getText().toString());
                task.setendtime(txtEndTime.getText().toString());
                if(task.getId() == 0)
                    new AddTaskAsyncTask(AddTaskActivity.this,AddTaskActivity.this ,task).execute();
                else
                    new UpdateTaskAsynTask(AddTaskActivity.this,task).execute();

            }
        });
    }


    private void addControls() {
        txtTitle = findViewById(R.id.txtTitleTask);
        txtDescr = findViewById(R.id.txtDescriptionTask);
        txtStartTime = findViewById(R.id.txtStartTime);
        txtEndTime = findViewById(R.id.txtEndTime);
        txtProgressValue = findViewById(R.id.txtProgressValue);
        spnPriority = findViewById(R.id.spnPriority);
        spnStatus = findViewById(R.id.spnStatus);
        sbProgress = findViewById(R.id.sbProgress);
        btnCan = findViewById(R.id.btnCancelTask);
        btnSave = findViewById(R.id.btnSaveTask);
        setAdapterPrio();
        setAdapterSta();
    }

    private void getInentTask()
    {
        Intent intentUpdateTask = getIntent();
        if(intentUpdateTask.hasExtra("task"))
        {
            task = (Task) intentUpdateTask.getSerializableExtra("task");
            txtTitle.setText(task.getTittle());
            txtDescr.setText(task.getDescription());
            txtEndTime.setText(task.getendtime());
            txtStartTime.setText(task.getStarttime());
            for (int i = 0; i < Statusses.length; i++)
            {
                if (Statusses[i].equals(task.getStatus())){
                    spnStatus.setSelection(i);
                }
            }
            for (int i = 0; i < Priorities.length; i++)
            {
                if(Priorities[i].equals(task.getPriority())){
                    spnPriority.setSelection(i);
                }
            }
            sbProgress.setProgress((int) task.getProgress());
            txtProgressValue.setText(task.getProgress()+"");
        }else{
            task = new Task();
        }
    }

    private void setAdapterSta() {
        adapterSta = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, Statusses);
        adapterSta.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnStatus.setAdapter(adapterSta);
    }

    private void setAdapterPrio() {
        adapterPrio = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, Priorities);
        adapterPrio.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnPriority.setAdapter(adapterPrio);
    }
    private void showTimePicker(EditText editText) {
        Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);
        TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                (TimePicker view, int selectedHour, int selectedMinute) -> {
                    String formattedTime = String.format("%02d:%02d", selectedHour, selectedMinute);
                    editText.setText(formattedTime);
                },
                hour, minute, true);
        timePickerDialog.show();
    }
    private void getIntentDayplanid()
    {
        Intent intentAddTask = getIntent();
        dayplanid = intentAddTask.getIntExtra("dayplanid", -1);
    }
    public void resetInputFields() {
        txtTitle.setText("");
        txtDescr.setText("");
        txtStartTime.setText("");
        txtEndTime.setText("");
        sbProgress.setProgress(0);
        spnPriority.setSelection(0);
        spnStatus.setSelection(0);
    }
}