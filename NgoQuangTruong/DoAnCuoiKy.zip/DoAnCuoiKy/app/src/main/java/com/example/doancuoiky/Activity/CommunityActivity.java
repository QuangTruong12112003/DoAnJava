package com.example.doancuoiky.Activity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.doancuoiky.Adapter.CommunityAdapter;
import com.example.doancuoiky.AsyncTask.GetCommunityAsyncTask;
import com.example.doancuoiky.Model.GoalPublic;
import com.example.doancuoiky.R;

import java.util.ArrayList;

public class CommunityActivity extends AppCompatActivity {
    CommunityAdapter adapter;
    ArrayList<GoalPublic> dsGoalPublic;
    ListView listView;
    Button btnquaylai;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_community);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        addControls();
        addEvenets();
        hienthi();
    }

    private void addEvenets() {
        btnquaylai.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }

    private void addControls() {
        listView = findViewById(R.id.goalscomListView);
        btnquaylai = findViewById(R.id.btnquaylai);
        dsGoalPublic = new ArrayList<>();
        adapter = new CommunityAdapter(CommunityActivity.this, R.layout.customer_from_community,dsGoalPublic);
        listView.setAdapter(adapter);
    }

    private void hienthi()
    {
        new GetCommunityAsyncTask(CommunityActivity.this,dsGoalPublic,adapter).execute();
    }
}