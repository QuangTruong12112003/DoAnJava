package com.example.doancuoiky.Activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.doancuoiky.Adapter.DayPlansAdpater;
import com.example.doancuoiky.AsyncTask.DeleteTaskAsynTask;
import com.example.doancuoiky.AsyncTask.DeleteTaskByDayplanIDAsyncTask;
import com.example.doancuoiky.AsyncTask.DisplayDayPlansAsyncTask;
import com.example.doancuoiky.AsyncTask.GetProgressGoalAsynTask;
import com.example.doancuoiky.AsyncTask.GetProgressGoalsAsyncTask;
import com.example.doancuoiky.AsyncTask.UpdateProgressGoalAsynTask;
import com.example.doancuoiky.Model.Dayplan;
import com.example.doancuoiky.Model.Goal;
import com.example.doancuoiky.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class DisplayDayplanActivity extends AppCompatActivity {

    TextView tvGoalTitleCS,tvDescriptionCS,tvTargetDateCS,tvVisibilityCS,tvStatusCs,tvProgressCs;
    Button btnCan, btnUpdate;
    FloatingActionButton fbThemDayplan;
    ListView listView;
    DayPlansAdpater dayPlansAdpaterd;
    ArrayList<Dayplan> dsDayplans;
    Goal goal;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_display_dayplan);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        addControls();
        hienthi();
        addEvents();

    }

    @Override
    protected void onRestart() {
        super.onRestart();
        hienthi();

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 2)
            if (resultCode == 3)
            {
                if (data.hasExtra("goal"))
                {
                    goal = (Goal) data.getSerializableExtra("goal");
                    tvGoalTitleCS.setText(goal.getGoal_tittle());
                    tvDescriptionCS.setText(goal.getDescription());
                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                    String formattedDate = dateFormat.format(goal.getTarget_date());
                    tvTargetDateCS.setText(formattedDate);
                    tvVisibilityCS.setText(goal.getVisibility());
                    tvStatusCs.setText(goal.getStatus());
                    tvProgressCs.setText(goal.getProgess()+"");
                }
            }
    }

    private void addEvents() {
        btnCan.setOnClickListener(view -> finish());
        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentUpdate = new Intent(DisplayDayplanActivity.this, AddGoalActivity.class);
                intentUpdate.putExtra("goal", goal);
                startActivityForResult(intentUpdate,2);
            }
        });
        fbThemDayplan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentAddDayplans = new Intent(DisplayDayplanActivity.this, AddDayplanActivity.class);
                intentAddDayplans.putExtra("goalid",goal.getId());
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                String formattedDate = dateFormat.format(goal.getTarget_date());
                intentAddDayplans.putExtra("targerdate",formattedDate);
                startActivityForResult(intentAddDayplans, 102);
            }
        });
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                Intent intentDayplanTT = new Intent(DisplayDayplanActivity.this, DisplayTaskActivity.class);
                Dayplan dayplan = dsDayplans.get(position);
                intentDayplanTT.putExtra("dayplan", dayplan);
                startActivityForResult(intentDayplanTT, 99);
            }
        });
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long l) {
                AlertDialog.Builder builder = new AlertDialog.Builder(DisplayDayplanActivity.this);
                builder.setTitle("XÓA");
                builder.setMessage("Bạn có muốn xóa nhiệm vụ này không!");
                builder.setPositiveButton("CÓ", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        new DeleteTaskByDayplanIDAsyncTask(DisplayDayplanActivity.this, dsDayplans.get(position).getId()).execute();
                        hienthi();
                    }
                });
                builder.setNegativeButton("KHÔNG", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });
                builder.setCancelable(false);
                builder.show();
                return true;
            }
        });
    }

    private void addControls() {
        tvGoalTitleCS = findViewById(R.id.tvGoalTitleCS);
        tvDescriptionCS = findViewById(R.id.tvDescriptionCS);
        tvTargetDateCS = findViewById(R.id.tvTargetDateCS);
        tvVisibilityCS = findViewById(R.id.tvVisibilityCS);
        tvStatusCs = findViewById(R.id.tvStatusCs);
        tvProgressCs = findViewById(R.id.tvProgressCs);
        btnCan = findViewById(R.id.btnCanGoal);
        btnUpdate = findViewById(R.id.btnUpdateGoal);
        fbThemDayplan = findViewById(R.id.fabAddDayplan);
        listView = findViewById(R.id.lvDayplans);
        dsDayplans = new ArrayList<>();
        dayPlansAdpaterd = new DayPlansAdpater(DisplayDayplanActivity.this, R.layout.customer_from_dayplan,dsDayplans);
        listView.setAdapter(dayPlansAdpaterd);
    }
    public void hienthi()
    {
        getIntentGoals();
        new DisplayDayPlansAsyncTask(DisplayDayplanActivity.this,dsDayplans,dayPlansAdpaterd).execute(goal.getId()+"");
        new GetProgressGoalsAsyncTask(DisplayDayplanActivity.this,goal.getId()).execute();
        //new GetProgressGoalAsynTask(DisplayDayplanActivity.this,goal.getId()).execute();
    }
    private void getIntentGoals()
    {
        Intent intentGoalTT = getIntent();
        if(intentGoalTT.hasExtra("goal"))
        {
            goal = (Goal) intentGoalTT.getSerializableExtra("goal");
            tvGoalTitleCS.setText(goal.getGoal_tittle());
            tvDescriptionCS.setText(goal.getDescription());
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String formattedDate = dateFormat.format(goal.getTarget_date());
            tvTargetDateCS.setText(formattedDate);
            tvVisibilityCS.setText(goal.getVisibility());
            tvStatusCs.setText(goal.getStatus());
            tvProgressCs.setText(goal.getProgess()+"");
        }
    }
    public void setTvProgress(double progress)
    {
        tvProgressCs.setText(progress+"%");
    }

}