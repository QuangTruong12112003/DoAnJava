package com.example.doancuoiky.Activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.doancuoiky.Adapter.TaskAdapter;
import com.example.doancuoiky.AsyncTask.DeleteTaskAsynTask;
import com.example.doancuoiky.AsyncTask.DisplayTaskAsyncTask;
import com.example.doancuoiky.AsyncTask.GetProgressDayplans;
import com.example.doancuoiky.AsyncTask.getProgressDayplanAsyncTask;
import com.example.doancuoiky.Model.Dayplan;
import com.example.doancuoiky.Model.Task;
import com.example.doancuoiky.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class DisplayTaskActivity extends AppCompatActivity {

    TextView tvDateCS,tvNotesCS,tvStatusDayplanCS,tvProgressDayplanCs;
    Button btnCanDayplan, btnUpdateDayplan;
    ListView lvTask;
    TaskAdapter adapter;
    ArrayList<Task> dsTask;
    Dayplan dayplan;
    FloatingActionButton fbAddTask;

    @Override
    protected void onRestart() {
        super.onRestart();
        hienthi();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_display_task);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        addControls();
        hienthi();
        addEvents();
    }
    private void addControls() {
        tvDateCS = findViewById(R.id.tvDateCS);
        tvNotesCS = findViewById(R.id.tvNotesCS);
        tvStatusDayplanCS = findViewById(R.id.tvStatusDayplanCS);
        tvProgressDayplanCs = findViewById(R.id.tvProgressDayplanCs);
        btnCanDayplan = findViewById(R.id.btnCanDayplanCS);
        btnUpdateDayplan = findViewById(R.id.btnUpdateDayplanCS);
        fbAddTask = findViewById(R.id.fabAddTask);
        lvTask = findViewById(R.id.lvTask);
        dsTask = new ArrayList<>();
        adapter = new TaskAdapter(DisplayTaskActivity.this,R.layout.customer_from_task,dsTask);
        lvTask.setAdapter(adapter);
    }
    private void addEvents() {
        btnCanDayplan.setOnClickListener(view -> finish());
        btnUpdateDayplan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentUpdateDayplan = new Intent(DisplayTaskActivity.this, AddDayplanActivity.class);
                intentUpdateDayplan.putExtra("dayplan", dayplan);
                startActivityForResult(intentUpdateDayplan,2);
            }
        });
        fbAddTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentAddTask = new Intent(DisplayTaskActivity.this, AddTaskActivity.class);
                intentAddTask.putExtra("dayplanid",dayplan.getId());
                startActivityForResult(intentAddTask, 6);
            }
        });
        lvTask.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                Task task = dsTask.get(position);
                Intent intentUpdateTask = new Intent(DisplayTaskActivity.this, AddTaskActivity.class);
                intentUpdateTask.putExtra("task", task);
                startActivityForResult(intentUpdateTask,4);
            }
        });
        lvTask.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long l) {
                AlertDialog.Builder builder = new AlertDialog.Builder(DisplayTaskActivity.this);
                builder.setTitle("XÓA");
                builder.setMessage("Bạn có muốn xóa nhiệm vụ này không!");
                builder.setPositiveButton("CÓ", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        new DeleteTaskAsynTask(DisplayTaskActivity.this, dsTask.get(position)).execute();
                        hienthi();
                    }
                });
                builder.setNegativeButton("KHÔNG", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });
                builder.setCancelable(false);
                builder.show();
                return true;
            }
        });

    }

    private void hienthi() {
        getIntentDayplan();
        new DisplayTaskAsyncTask(DisplayTaskActivity.this,dsTask, adapter).execute(dayplan.getId()+"");
        new GetProgressDayplans(DisplayTaskActivity.this,dayplan.getId()).execute();
        new getProgressDayplanAsyncTask(DisplayTaskActivity.this,dayplan.getId()).execute();
    }

    private void getIntentDayplan()
    {
        Intent intentDayplanTT = getIntent();
        if(intentDayplanTT.hasExtra("dayplan"))
        {
            dayplan = (Dayplan) intentDayplanTT.getSerializableExtra("dayplan");
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String formattedDate = dateFormat.format(dayplan.getDate());
            tvDateCS.setText(formattedDate);
            tvNotesCS.setText(dayplan.getNotes());
            tvStatusDayplanCS.setText(dayplan.getStatus());
            tvProgressDayplanCs.setText(dayplan.getProgress()+"");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 2)
            if (resultCode == 3)
            {
                if (data.hasExtra("dayplan"))
                {
                    dayplan = (Dayplan) data.getSerializableExtra("dayplan");
                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                    String formattedDate = dateFormat.format(dayplan.getDate());
                    tvDateCS.setText(formattedDate);
                    tvNotesCS.setText(dayplan.getNotes());
                    tvStatusDayplanCS.setText(dayplan.getStatus());
                    tvProgressDayplanCs.setText(dayplan.getProgress()+"");
                }
            }
    }
    public void setTvProgress(double progress)
    {
        tvProgressDayplanCs.setText(progress+"%");
    }
}