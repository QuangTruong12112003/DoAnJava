package com.example.doancuoiky.Activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.doancuoiky.Adapter.GoalsAdapter;
import com.example.doancuoiky.AsyncTask.DeleteGoalAsyncTask;
import com.example.doancuoiky.AsyncTask.DiplaysGoalAsyncTask;
import com.example.doancuoiky.Model.Goal;
import com.example.doancuoiky.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    DrawerLayout drawerLayout;
    ImageButton btnDrawerToggle;
    NavigationView nagigationView;
    TextView tvUserName;
    TextView tvUserEmail;
    ListView listView;
    GoalsAdapter adapter;
    ArrayList<Goal> dsGoals;
    FloatingActionButton fbAddGoal;
    int UserID;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        addControls();
        addEvents();
        getInforUser();
        if(UserID != -1){
            hienthiGoals(UserID);
        }
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        hienthiGoals(UserID);
    }

    private void getInforUser() {
        SharedPreferences sharedPreferences = getSharedPreferences("UserSession", MODE_PRIVATE);

        String email = sharedPreferences.getString("Email", null);
        String userName = sharedPreferences.getString("Name", null);
        UserID = sharedPreferences.getInt("UserID", -1);
        boolean isLoggedIn = sharedPreferences.getBoolean("isLoggedIn", false);

        if(isLoggedIn){
            tvUserName.setText(userName);
            tvUserEmail.setText(email);
        }else{
            Toast.makeText(this, "Người dùng chưa đăng nhập!", Toast.LENGTH_SHORT).show();
            UserID = -1;
        }
    }

    private void addEvents() {
        btnDrawerToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.open();
            }
        });
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                Intent intentGoalTT = new Intent(MainActivity.this, DisplayDayplanActivity.class);
                Goal goal = dsGoals.get(position);
                intentGoalTT.putExtra("goal", goal);
                startActivityForResult(intentGoalTT, 99);
            }
        });

        fbAddGoal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent addintentGoal = new Intent(MainActivity.this, AddGoalActivity.class);
                startActivityForResult(addintentGoal,100);
            }
        });

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long l) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("XÓA");
                builder.setMessage("Bạn có muốn xóa mục tiêu này không!");
                builder.setPositiveButton("CÓ", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        new DeleteGoalAsyncTask(MainActivity.this,dsGoals.get(position).getId(),UserID).execute();
                    }
                });
                builder.setNegativeButton("KHÔNG", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });
                builder.setCancelable(false);
                builder.show();
                return true;
            }
        });
        nagigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();
                if(itemId == R.id.navThongbao){
                    Toast.makeText(MainActivity.this, "Mục tiêu được click", Toast.LENGTH_SHORT).show();
                }
                if(itemId == R.id.navCongDong){
                    Intent intentcd = new Intent(MainActivity.this, CommunityActivity.class);
                    startActivity(intentcd);
                }
                if(itemId == R.id.navDangXuat){

                    finish();
                }
                drawerLayout.close();
                return false;
            }
        });

    }

    private void addControls() {
        drawerLayout = findViewById(R.id.drawerlayout);
        btnDrawerToggle = findViewById(R.id.btnDrawerToggle);
        nagigationView = findViewById(R.id.navigationView);
        View headerView = nagigationView.getHeaderView(0);
        tvUserName = headerView.findViewById(R.id.tvUsername);
        tvUserEmail = headerView.findViewById(R.id.tvUserEmail);
        listView = findViewById(R.id.goalsListView);
        fbAddGoal = findViewById(R.id.fabAddGoal);
        dsGoals = new ArrayList<>();
        adapter = new GoalsAdapter(MainActivity.this, R.layout.customer_from_goals,dsGoals);
        listView.setAdapter(adapter);
    }


    public void hienthiGoals(int id)
    {
        DiplaysGoalAsyncTask asyncTask = new DiplaysGoalAsyncTask(this, dsGoals, adapter);
        asyncTask.execute(String.valueOf(id));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100)
            if (resultCode == 101)
            {
                if(data.hasExtra("goalid")) {
                    int goalid = data.getIntExtra("goalid",-1);
                    String date = data.getStringExtra("targerdate");
                    if(goalid != -1) {
                        Intent intentAddDayplans = new Intent(MainActivity.this, AddDayplanActivity.class);
                        intentAddDayplans.putExtra("goalid",goalid );
                        intentAddDayplans.putExtra("targerdate",date);
                        startActivityForResult(intentAddDayplans, 102);
                        Toast.makeText(this, "Thêm kế hoạch ngày cho mục tiêu " + goalid, Toast.LENGTH_SHORT).show();
                    }
                }
            }
    }
}