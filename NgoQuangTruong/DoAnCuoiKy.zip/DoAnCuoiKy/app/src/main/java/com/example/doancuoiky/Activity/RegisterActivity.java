package com.example.doancuoiky.Activity;

import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.Volley;
import com.example.doancuoiky.Network.UserNetworkManager;
import com.example.doancuoiky.R;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class RegisterActivity extends AppCompatActivity {
    private EditText txtName, txtEmail, txtPass, txtRe_Pass;
    private Button btnRegister;
    private TextView tvLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_register);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        addControls();
        addEvents();
    }

    private void addControls() {
        txtName = findViewById(R.id.txtName);
        txtEmail = findViewById(R.id.txtEmail);
        txtPass = findViewById(R.id.txtPassword_Register);
        txtRe_Pass = findViewById(R.id.txtRe_Password_Register);
        btnRegister = findViewById(R.id.btnRegister);
        tvLogin = findViewById(R.id.tvLogin);
    }

    private void addEvents() {
        tvLogin.setOnClickListener(view -> {
            finish();
        });
        btnRegister.setOnClickListener(view -> {
            String name = txtName.getText().toString().trim();
            String email = txtEmail.getText().toString().trim();
            String pass = txtPass.getText().toString().trim();
            String re_pass = txtRe_Pass.getText().toString().trim();

            if (name.isEmpty() || email.isEmpty() || pass.isEmpty() || re_pass.isEmpty()) {
                Toast.makeText(this, "Vui lòng điền đầy đủ thông tin", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!pass.equals(re_pass)) {
                Toast.makeText(this, "Mật khẩu không khớp", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                Toast.makeText(this, "Email không hợp lệ", Toast.LENGTH_SHORT).show();
                return;
            }

            RequestQueue requestQueue = Volley.newRequestQueue(this);

            UserNetworkManager.checkUserExists(requestQueue, email, exists -> {
                if (exists) {
                    Toast.makeText(this, "Email đã tồn tại", Toast.LENGTH_SHORT).show();
                } else {
                    String hashedPass = hashPassword(pass);
                    if(hashedPass != null) {
                        UserNetworkManager.registerUser(requestQueue, name, email, hashedPass, result -> {
                            Toast.makeText(this, result, Toast.LENGTH_SHORT).show();
                            if (result.equals("Đăng ký thành công")) {
                                finish();
                            }
                        });
                    }
                    else{
                        Toast.makeText(this, "Mật khẩu bâm thất bại", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        });
    }
    private String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(password.getBytes());

            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }
}
