package com.example.doancuoiky.Adapter;

import static android.content.Context.MODE_PRIVATE;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.doancuoiky.AsyncTask.AddFollowerGoalAsynTask;
import com.example.doancuoiky.AsyncTask.CopyGoalAsyncTask;
import com.example.doancuoiky.AsyncTask.GetFollowerOfUser;
import com.example.doancuoiky.Connect.Connect;
import com.example.doancuoiky.Model.Follower;
import com.example.doancuoiky.Model.Goal;
import com.example.doancuoiky.Model.GoalPublic;
import com.example.doancuoiky.Model.User;
import com.example.doancuoiky.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CommunityAdapter extends ArrayAdapter<GoalPublic> {
    Context context;
    int resource;
    ArrayList<GoalPublic> objects;
    ArrayList<Follower> dsFollowe = new ArrayList<>();
    int UserID;
    private boolean isLiked = false;
    public CommunityAdapter(@NonNull Context context, int resource, @NonNull ArrayList<GoalPublic> objects) {
        super(context, resource, objects);
        this.context = context;
        this.resource = resource;
        this.objects = objects;

    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View item = layoutInflater.inflate(this.resource, null);
        TextView tvGoalTittle =item.findViewById(R.id.tvGoalTitleCD);
        TextView tvDescription = item.findViewById(R.id.tvDescriptionCD);
        TextView tvtarget = item.findViewById(R.id.tvTargetDateCD);
        TextView tvVisibility = item.findViewById(R.id.tvVisibilityCD);
        TextView tvStatus = item.findViewById(R.id.tvStatusCD);
        TextView tvName = item.findViewById(R.id.tvNameUser);
        TextView tvdelete = item.findViewById(R.id.tvdelete);
        TextView tvlike = item.findViewById(R.id.tvLike);
        ImageButton ic_delete = item.findViewById(R.id.ivDelete);
        ImageButton ic_like = item.findViewById(R.id.ivLike);
        ImageButton ic_save = item.findViewById(R.id.ivSave);

        GoalPublic goal =objects.get(position);
        tvName.setText(goal.getName());
        tvGoalTittle.setText(goal.getGoal_tittle());
        tvDescription.setText(goal.getDescription());
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String formattedDate = dateFormat.format(goal.getTarget_date());
        tvtarget.setText(formattedDate);
        tvVisibility.setText(goal.getVisibility());
        tvStatus.setText(goal.getStatus());
        getInforUser();


        ic_like.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (goal.getUser_id() != UserID) {
                    new AddFollowerGoalAsynTask(context, UserID, goal.getId()).execute();
                    ic_like.setVisibility(view.GONE);
                    tvlike.setVisibility(view.GONE);

                    ic_delete.setVisibility(view.VISIBLE);
                    tvdelete.setVisibility(view.VISIBLE);
                }

                else
                    Toast.makeText(context, "Đây là dự án của bạn", Toast.LENGTH_SHORT).show();
            }
        });
        ic_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (goal.getUser_id() != UserID) {
                    new CopyGoalAsyncTask(context, goal.getId(), UserID).execute();
                }else{
                    Toast.makeText(context, "Đây là dự án của bạn", Toast.LENGTH_SHORT).show();
                }
            }
        });
        return item;

    }
    private void getInforUser() {
        SharedPreferences sharedPreferences = context.getSharedPreferences("UserSession", MODE_PRIVATE);
        UserID = sharedPreferences.getInt("UserID", -1);

    }



}
