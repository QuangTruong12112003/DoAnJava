package com.example.doancuoiky.Adapter;

import android.content.ContentValues;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.doancuoiky.Model.Dayplan;
import com.example.doancuoiky.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class DayPlansAdpater extends ArrayAdapter<Dayplan> {
    private Context context;
    private int resource;
    private ArrayList<Dayplan> objects;
    public DayPlansAdpater(@NonNull Context context, int resource, @NonNull ArrayList<Dayplan> objects) {
        super(context, resource, objects);
        this.context = context;
        this.resource = resource;
        this.objects = objects;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View item = layoutInflater.inflate(this.resource, null);
        TextView tvDate = item.findViewById(R.id.tvDateDayplan);
        TextView tvNotes = item.findViewById(R.id.tvNotes);
        TextView tvStatus = item.findViewById(R.id.tvStatusDayPlan);
        TextView tvProgrss = item.findViewById(R.id.tvProgressDayplan);


        Dayplan dayplan = objects.get(position);
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String formattedDate = dateFormat.format(dayplan.getDate());
        tvDate.setText(formattedDate);
        tvNotes.setText(dayplan.getNotes());
        tvStatus.setText(dayplan.getStatus());
        tvProgrss.setText(dayplan.getProgress()+"");
        return item;
    }
}
