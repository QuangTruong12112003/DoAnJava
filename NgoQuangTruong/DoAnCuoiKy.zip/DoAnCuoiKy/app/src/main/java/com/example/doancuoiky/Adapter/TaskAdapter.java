package com.example.doancuoiky.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.doancuoiky.Model.Task;
import com.example.doancuoiky.R;

import java.util.ArrayList;
import java.util.List;

public class TaskAdapter extends ArrayAdapter<Task> {
    private Context context;
    private int resource;
    private ArrayList<Task> objects;
    public TaskAdapter(@NonNull Context context, int resource, @NonNull ArrayList<Task> objects) {
        super(context, resource, objects);
        this.context = context;
        this.resource = resource;
        this.objects = objects;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View item = layoutInflater.inflate(this.resource, null);
        TextView tvTitle = item.findViewById(R.id.tvTaskTitle);
        TextView tvDescr = item.findViewById(R.id.tvDescriptionTask);
        TextView tvPriority = item.findViewById(R.id.tvPriority);
        TextView tvStatus = item.findViewById(R.id.tvStatusTask);
        TextView tvProgress = item.findViewById(R.id.tvProgressTask);
        TextView tvstarttime = item.findViewById(R.id.tvStartTime);
        TextView tvendtime = item.findViewById(R.id.tvEndTime);

        Task task = objects.get(position);
        tvTitle.setText(task.getTittle());
        tvDescr.setText(task.getDescription());
        tvPriority.setText(task.getPriority());
        tvStatus.setText(task.getStatus());
        tvProgress.setText(task.getProgress()+"");
        tvstarttime.setText(task.getStarttime()+"");
        tvendtime.setText(task.getendtime()+"");
        return item;
    }
}
