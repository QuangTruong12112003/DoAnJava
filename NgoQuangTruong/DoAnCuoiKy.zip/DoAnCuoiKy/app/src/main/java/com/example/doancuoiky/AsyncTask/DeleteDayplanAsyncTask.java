package com.example.doancuoiky.AsyncTask;

import android.app.ProgressDialog;
import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.doancuoiky.Activity.DisplayDayplanActivity;
import com.example.doancuoiky.Connect.Connect;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class DeleteDayplanAsyncTask extends AsyncTask<String, Void, Boolean> {
    private ProgressDialog progressDialog;
    private Context context;
    private DisplayDayplanActivity activity;
    int flag = 0;

    public DeleteDayplanAsyncTask(Context context)
    {
        this.context = context;
        if (context instanceof DisplayDayplanActivity) {
            this.activity = (DisplayDayplanActivity) context;
        }
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        progressDialog = new ProgressDialog(context);
        progressDialog.setMessage("Đang tải dữ liệu...");
        progressDialog.setCancelable(false);
        try {
            progressDialog.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected Boolean doInBackground(String... params) {
        int DayPlanID = Integer.parseInt(params[0]);
        RequestQueue requestQueue = Volley.newRequestQueue(context);
        Uri.Builder builder = Uri.parse(Connect.SERVER_POST).buildUpon();
        String url = builder.build().toString();
        StringRequest postRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    boolean result = jsonObject.getBoolean("message");
                    if (result) {
                        onPostExecute(true);
                    } else {
                        onPostExecute(false);
                    }
                } catch (JSONException e) {
                    throw new RuntimeException(e);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(context,  error.getMessage(), Toast.LENGTH_SHORT).show();
                onPostExecute(false);
            }
        }) {
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("action", "deleteDayPlan");
                params.put("DayPlanID", DayPlanID+"");
                return params;
            }
        };
        requestQueue.add(postRequest);
        return null;

    }

    @Override
    protected void onPostExecute(Boolean aBoolean) {
        super.onPostExecute(aBoolean);
        if (flag == 1) {

            if (progressDialog.isShowing()) {
                progressDialog.dismiss();
            }

            if (aBoolean) {
                Toast.makeText(context, "Xóa thành công", Toast.LENGTH_SHORT).show();
                if (activity != null) {
                    activity.hienthi();
                }
            } else {
                Toast.makeText(context, "Xóa thất bại", Toast.LENGTH_SHORT).show();
            }
            flag = 0;
        } else {
            flag++;
        }
    }
}
