package com.example.doancuoiky.AsyncTask;

import android.app.ProgressDialog;
import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.doancuoiky.Activity.DisplayDayplanActivity;
import com.example.doancuoiky.Activity.MainActivity;
import com.example.doancuoiky.Adapter.DayPlansAdpater;
import com.example.doancuoiky.Connect.Connect;
import com.example.doancuoiky.Model.Dayplan;
import com.example.doancuoiky.Model.Goal;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class DisplayDayPlansAsyncTask extends AsyncTask<String, Void, ArrayList<Dayplan>> {
    private Context context;
    private ProgressDialog progressDialog;
    private ArrayList<Dayplan> dsDayplans;
    private DayPlansAdpater adapter;
    private  int flag = 0;

    public DisplayDayPlansAsyncTask(Context context, ArrayList<Dayplan> dsDayplans, DayPlansAdpater adapter){
        this.context = context;
        this.dsDayplans = dsDayplans;
        this.adapter = adapter;
    }


    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        progressDialog = new ProgressDialog(context);
        progressDialog.setMessage("Đang tải dữ liệu...");
        progressDialog.setCancelable(false);
        try {
            progressDialog.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected ArrayList<Dayplan> doInBackground(String... params) {
        int GoalID = Integer.parseInt(params[0]);
        ArrayList<Dayplan> dayplanList = new ArrayList<>();

        try {
            RequestQueue requestQueue = Volley.newRequestQueue(context);
            Uri.Builder builder = Uri.parse(Connect.SERVER_GET).buildUpon();
            builder.appendQueryParameter("action", "getAllDayPlans");
            builder.appendQueryParameter("GoalID", String.valueOf(GoalID));
            String url = builder.build().toString();

            StringRequest getRequest = new StringRequest(Request.Method.GET, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try {
                                JSONArray jsonArray = new JSONArray(response);
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                                    int ma = jsonObject.getInt("DayPlanID");
                                    int GoalID = jsonObject.getInt("GoalID");
                                    String targetDateString = jsonObject.getString("Date");
                                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                                    Date Date = dateFormat.parse(targetDateString);
                                    String Notes = jsonObject.getString("Notes");
                                    String status = jsonObject.getString("Status");
                                    double progress = jsonObject.getDouble("Progress");

                                    dayplanList.add(new Dayplan(ma,GoalID,Date,Notes, status,progress));
                                }
                            } catch (JSONException | ParseException e) {
                                e.printStackTrace();
                            }
                            ((DisplayDayplanActivity) context).runOnUiThread(() -> onPostExecute(dayplanList));
                        }

                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(context, "Lỗi khi tải dữ liệu: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                            ((DisplayDayplanActivity) context).runOnUiThread(() -> onPostExecute(dayplanList));
                        }
                    });

            requestQueue.add(getRequest);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    protected void onPostExecute(ArrayList<Dayplan> dayplans) {
        super.onPostExecute(dayplans);
        if(flag == 1) {

            if (progressDialog.isShowing()) {
                progressDialog.dismiss();
            }

            if (dayplans != null) {
                dsDayplans.clear();
                dsDayplans.addAll(dayplans);
                adapter.notifyDataSetChanged();
            } else {
                Toast.makeText(context, "Không có dữ liệu để hiển thị", Toast.LENGTH_SHORT).show();
            }
            flag = 0;
        }else {
            flag++;
        }
    }
}
