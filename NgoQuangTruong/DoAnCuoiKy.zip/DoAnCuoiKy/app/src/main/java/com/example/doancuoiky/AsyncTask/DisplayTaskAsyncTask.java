package com.example.doancuoiky.AsyncTask;

import android.app.ProgressDialog;
import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.doancuoiky.Activity.DisplayDayplanActivity;
import com.example.doancuoiky.Activity.DisplayTaskActivity;
import com.example.doancuoiky.Adapter.DayPlansAdpater;
import com.example.doancuoiky.Adapter.TaskAdapter;
import com.example.doancuoiky.Connect.Connect;
import com.example.doancuoiky.Model.Dayplan;
import com.example.doancuoiky.Model.Task;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class DisplayTaskAsyncTask extends AsyncTask<String, Void, ArrayList<Task>> {
    private Context context;
    private ProgressDialog progressDialog;
    private ArrayList<Task> dsTask;
    private TaskAdapter adapter;
    private  int flag = 0;

    public DisplayTaskAsyncTask(Context context, ArrayList<Task> dsTask, TaskAdapter adapter)
    {
        this.context = context;
        this.dsTask = dsTask;
        this.adapter = adapter;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        progressDialog = new ProgressDialog(context);
        progressDialog.setMessage("Đang tải dữ liệu...");
        progressDialog.setCancelable(false);
        try {
            progressDialog.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected ArrayList<Task> doInBackground(String... params) {
        int DayplanID = Integer.parseInt(params[0]);
        ArrayList<Task> taskList = new ArrayList<>();

        try {
            RequestQueue requestQueue = Volley.newRequestQueue(context);
            Uri.Builder builder = Uri.parse(Connect.SERVER_GET).buildUpon();
            builder.appendQueryParameter("action", "getAllTasks");
            builder.appendQueryParameter("DayPlanID", String.valueOf(DayplanID));
            String url = builder.build().toString();

            StringRequest getRequest = new StringRequest(Request.Method.GET, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try {
                                JSONArray jsonArray = new JSONArray(response);
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                                    int TaskID = jsonObject.getInt("TaskID");
                                    int DayPlanID = jsonObject.getInt("DayPlanID");
                                    String Title = jsonObject.getString("Title");
                                    String Description = jsonObject.getString("Description");
                                    String Priority = jsonObject.getString("Priority");
                                    String Status = jsonObject.getString("Status");
                                    double Progress = jsonObject.getDouble("Progress");
                                    String StartTimeString = jsonObject.getString("StartTime");
                                    String EndTimeString = jsonObject.getString("EndTime");
                                    taskList.add(new Task(TaskID,DayPlanID,Title,Description,Priority,Status,Progress,StartTimeString,EndTimeString));
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                            ((DisplayTaskActivity) context).runOnUiThread(() -> onPostExecute(taskList));
                        }

                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(context, "Lỗi khi tải dữ liệu: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                            ((DisplayTaskActivity) context).runOnUiThread(() -> onPostExecute(taskList));
                        }
                    });

            requestQueue.add(getRequest);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    protected void onPostExecute(ArrayList<Task> tasks) {
        super.onPostExecute(tasks);
        if(flag == 1) {

            if (progressDialog.isShowing()) {
                progressDialog.dismiss();
            }

            if (tasks != null) {
                dsTask.clear();
                dsTask.addAll(tasks);
                adapter.notifyDataSetChanged();
            } else {
                Toast.makeText(context, "Không có dữ liệu để hiển thị", Toast.LENGTH_SHORT).show();
            }
            flag = 0;
        }else {
            flag++;
        }
    }
}
