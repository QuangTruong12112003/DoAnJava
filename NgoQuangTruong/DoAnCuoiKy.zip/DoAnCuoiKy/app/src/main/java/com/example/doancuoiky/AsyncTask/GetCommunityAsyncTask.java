package com.example.doancuoiky.AsyncTask;

import android.app.ProgressDialog;
import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.doancuoiky.Activity.CommunityActivity;
import com.example.doancuoiky.Activity.MainActivity;
import com.example.doancuoiky.Adapter.CommunityAdapter;
import com.example.doancuoiky.Adapter.GoalsAdapter;
import com.example.doancuoiky.Connect.Connect;
import com.example.doancuoiky.Model.Goal;
import com.example.doancuoiky.Model.GoalPublic;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class GetCommunityAsyncTask extends AsyncTask<String, Void, ArrayList<GoalPublic>> {
    private Context context;
    private ProgressDialog progressDialog;
    private ArrayList<GoalPublic> dsGoals;
    private CommunityAdapter adapter;
    private  int flag = 0;

    public GetCommunityAsyncTask(Context context, ArrayList<GoalPublic> dsGoals, CommunityAdapter adapter) {
        this.context = context;
        this.dsGoals = dsGoals;
        this.adapter = adapter;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        progressDialog = new ProgressDialog(context);
        progressDialog.setMessage("Đang tải dữ liệu...");
        progressDialog.setCancelable(false);
        try {
            progressDialog.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected ArrayList<GoalPublic> doInBackground(String... strings) {
        ArrayList<GoalPublic> goalsList = new ArrayList<>();

        try {
            RequestQueue requestQueue = Volley.newRequestQueue(context);
            Uri.Builder builder = Uri.parse(Connect.SERVER_GET).buildUpon();
            builder.appendQueryParameter("action", "getGoalPublic");
            String url = builder.build().toString();

            StringRequest getRequest = new StringRequest(Request.Method.GET, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try {
                                JSONArray jsonArray = new JSONArray(response);
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                                    int ma = jsonObject.getInt("GoalID");
                                    int userID = jsonObject.getInt("UserID");
                                    String goaltitle = jsonObject.getString("GoalTitle");
                                    String description = jsonObject.getString("Description");
                                    String targetDateString = jsonObject.getString("TargetDate");
                                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                                    Date targetDate = dateFormat.parse(targetDateString);
                                    String visibility = jsonObject.getString("Visibility");
                                    String status = jsonObject.getString("Status");
                                    double progress = jsonObject.getDouble("Progress");
                                    String name = jsonObject.getString("Name");

                                    goalsList.add(new GoalPublic(ma, userID, goaltitle, description, targetDate, visibility, status, progress,name));
                                }
                            } catch (JSONException | ParseException e) {
                                e.printStackTrace();
                            }
                            ((CommunityActivity) context).runOnUiThread(() -> onPostExecute(goalsList));
                        }

                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(context, "Lỗi khi tải dữ liệu: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                            ((CommunityActivity) context).runOnUiThread(() -> onPostExecute(goalsList));
                        }
                    });

            requestQueue.add(getRequest);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    protected void onPostExecute(ArrayList<GoalPublic> goalPublics) {
        super.onPostExecute(goalPublics);
        if(flag == 1) {

            if (progressDialog.isShowing()) {
                progressDialog.dismiss();
            }

            if (goalPublics != null) {
                dsGoals.clear();
                dsGoals.addAll(goalPublics);
                adapter.notifyDataSetChanged();
            } else {
                Toast.makeText(context, "Không có dữ liệu để hiển thị", Toast.LENGTH_SHORT).show();
            }
            flag = 0;
        }else {
            flag++;
        }
    }
}
