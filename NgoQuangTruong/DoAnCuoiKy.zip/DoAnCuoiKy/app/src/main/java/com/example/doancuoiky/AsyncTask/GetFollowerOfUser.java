package com.example.doancuoiky.AsyncTask;

import android.app.ProgressDialog;
import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.doancuoiky.Activity.DisplayDayplanActivity;
import com.example.doancuoiky.Adapter.DayPlansAdpater;
import com.example.doancuoiky.Connect.Connect;
import com.example.doancuoiky.Model.Dayplan;
import com.example.doancuoiky.Model.Follower;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class GetFollowerOfUser extends AsyncTask<String, Void, Boolean> {
    private Context context;
    private int goalid;
    private int userid;
    private ProgressDialog progressDialog;
    private boolean isFollowed = false;
    private Callback callback;

    public interface Callback {
        void onResult(boolean isFollowed);
    }

    public GetFollowerOfUser(Context context, int userid, int goalid, Callback callback) {
        this.context = context;
        this.userid = userid;
        this.goalid = goalid;
        this.callback = callback;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        progressDialog = new ProgressDialog(context);
        progressDialog.setMessage("Đang tải dữ liệu...");
        progressDialog.setCancelable(false);
        try {
            progressDialog.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected Boolean doInBackground(String... strings) {
        RequestQueue requestQueue = Volley.newRequestQueue(context);
        Uri.Builder builder = Uri.parse(Connect.SERVER_POST).buildUpon();
        String url = builder.build().toString();
        StringRequest postRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    boolean result = jsonObject.getBoolean("message");
                    isFollowed = result; // Set isFollowed to true if message is true
                    if (callback != null) {
                        callback.onResult(isFollowed); // Pass the result back
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                } finally {
                    dismissProgressDialog();  // Tắt ProgressDialog ở đây
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(context, error.getMessage(), Toast.LENGTH_SHORT).show();
                dismissProgressDialog();  // Tắt ProgressDialog khi có lỗi
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                HashMap<String, String> params = new HashMap<>();
                params.put("action", "checkGoalAndUserExist");
                params.put("GoalID", goalid + "");
                params.put("UserID", userid + "");
                return params;
            }
        };
        requestQueue.add(postRequest);
        return null;
    }
    private void dismissProgressDialog() {
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
    }

}
