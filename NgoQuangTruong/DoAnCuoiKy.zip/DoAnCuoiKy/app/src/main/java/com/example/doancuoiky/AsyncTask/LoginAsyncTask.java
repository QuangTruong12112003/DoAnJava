package com.example.doancuoiky.AsyncTask;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.AsyncTask;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.doancuoiky.Activity.MainActivity;
import com.example.doancuoiky.Connect.Connect;
import com.example.doancuoiky.Model.User;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class LoginAsyncTask extends AsyncTask<String, Void, Boolean> {
    private Context context;
    private ProgressDialog progressDialog;
    private String enteredPassword;
    private  int flag = 0;

    public LoginAsyncTask(Context context){
        this.context = context;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        progressDialog =  new ProgressDialog(context);
        progressDialog.setMessage("Đang đăng nhập...");
        progressDialog.setCancelable(false);
        progressDialog.show();
    }


    @Override
    protected Boolean doInBackground(String... params) {
        String email = params[0];
        enteredPassword = params[1];
        final boolean[] isLoginSuccessful = {false};

        try {
            RequestQueue requestQueue = Volley.newRequestQueue(context);
            Uri.Builder builder = Uri.parse(Connect.SERVER_POST).buildUpon();
            String url = builder.build().toString();

            StringRequest postRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    try {
                        JSONArray jsonArray = new JSONArray(response);
                        if (jsonArray.length() > 0)
                        {
                            JSONObject jsonObject = jsonArray.getJSONObject(0);
                            int id = jsonObject.getInt("UserID");
                            String name =  jsonObject.getString("Name");
                            String email = jsonObject.getString("Email");
                            String pass = jsonObject.getString("Password");
                            String role = jsonObject.getString("Role");
                            String storedPassword = jsonObject.getString("Password");

                            if(storedPassword.equals(enteredPassword)){
                                SharedPreferences sharedPreferences = context.getSharedPreferences("UserSession", Context.MODE_PRIVATE);
                                SharedPreferences.Editor editor = sharedPreferences.edit();
                                editor.putInt("UserID",id);
                                editor.putString("Name", name);
                                editor.putString("Email",email);
                                editor.putString("Password", pass);
                                editor.putString("Role" , role);
                                editor.putBoolean("isLoggedIn", true);
                                editor.apply();
                                isLoginSuccessful[0] = true;
                            }
                        }
                    } catch (JSONException e) {
                        throw new RuntimeException(e);
                    }
                    onPostExecute(isLoginSuccessful[0]);
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(context, error.getMessage(), Toast.LENGTH_SHORT).show();
                    onPostExecute(false);
                }
            })
            {
                @Nullable
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    HashMap<String, String> params = new HashMap<>();
                    params.put("action", "getUser");
                    params.put("Email", email);
                    return params;
                }
            };
            requestQueue.add(postRequest);
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onPostExecute(Boolean result) {
        super.onPostExecute(result);
        if(flag == 1) {
            if (progressDialog != null && progressDialog.isShowing()) {
                progressDialog.dismiss();
            }
            if (result != null && result) {
                Toast.makeText(context, "Đăng nhập thành công", Toast.LENGTH_SHORT).show();
                Intent intentUser = new Intent(context, MainActivity.class);
                context.startActivity(intentUser);
            } else {
                Toast.makeText(context, "Đăng nhập thất bại", Toast.LENGTH_SHORT).show();
            }
        }else{
            flag++;
        }
    }
}
