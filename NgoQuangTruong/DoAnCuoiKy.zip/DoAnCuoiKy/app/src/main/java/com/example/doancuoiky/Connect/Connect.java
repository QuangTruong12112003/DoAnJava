package com.example.doancuoiky.Connect;

public class Connect {
    public static final String SERVER_GET = "http://192.168.102.148/DoAnCuoiKyAndroid/api.php";
    public static final String SERVER_POST ="http://192.168.102.148/DoAnCuoiKyAndroid/api_post.php";
}
