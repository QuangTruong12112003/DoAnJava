package com.example.doancuoiky.Model;

import java.io.Serializable;
import java.util.Date;

public class Dayplan implements Serializable {
    private int id;
    private int goal_id;
    private Date date;
    private String Notes;
    private String Status;
    private double progress;

    public Dayplan(int id, int goal_id, Date date, String notes, String status, double progress) {
        this.id = id;
        this.goal_id = goal_id;
        this.date = date;
        Notes = notes;
        Status = status;
        this.progress = progress;
    }

    public Dayplan(int goal_id, Date date, String notes, String status, double progress) {
        this.goal_id = goal_id;
        this.date = date;
        Notes = notes;
        Status = status;
        this.progress = progress;
    }

    public Dayplan() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getGoal_id() {
        return goal_id;
    }

    public void setGoal_id(int goal_id) {
        this.goal_id = goal_id;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getNotes() {
        return Notes;
    }

    public void setNotes(String notes) {
        Notes = notes;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }

    public double getProgress() {
        return progress;
    }

    public void setProgress(double progress) {
        this.progress = progress;
    }
}
