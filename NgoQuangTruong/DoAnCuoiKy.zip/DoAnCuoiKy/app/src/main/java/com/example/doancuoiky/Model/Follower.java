package com.example.doancuoiky.Model;

import java.io.Serializable;
import java.util.Date;

public class Follower implements Serializable {
    private int id;
    private int goal_id;
    private int user_id;
    private Date follower_at;

    public Follower(int id, int goal_id, int user_id, Date follower_at) {
        this.id = id;
        this.goal_id = goal_id;
        this.user_id = user_id;
        this.follower_at = follower_at;
    }

    public Follower(int goal_id, int user_id, Date follower_at) {
        this.goal_id = goal_id;
        this.user_id = user_id;
        this.follower_at = follower_at;
    }

    public Follower() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getGoal_id() {
        return goal_id;
    }

    public void setGoal_id(int goal_id) {
        this.goal_id = goal_id;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public Date getFollower_at() {
        return follower_at;
    }

    public void setFollower_at(Date follower_at) {
        this.follower_at = follower_at;
    }
}
