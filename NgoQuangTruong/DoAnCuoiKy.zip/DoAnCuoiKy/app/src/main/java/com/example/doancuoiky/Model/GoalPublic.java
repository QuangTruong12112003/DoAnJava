package com.example.doancuoiky.Model;

import java.io.Serializable;
import java.util.Date;

public class GoalPublic implements Serializable {
    private int id;
    private int user_id;
    private String goal_tittle;
    private String description;
    private Date target_date;
    private String visibility;
    private String status;
    private double progess;
    private String name;

    public GoalPublic(int id, int user_id, String goal_tittle, String description, Date target_date, String visibility, String status, double progess, String name) {
        this.id = id;
        this.user_id = user_id;
        this.goal_tittle = goal_tittle;
        this.description = description;
        this.target_date = target_date;
        this.visibility = visibility;
        this.status = status;
        this.progess = progess;
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public GoalPublic() {
    }

    public GoalPublic(int user_id, String goal_tittle, String description, Date target_date, String visibility, String status, double progess, String name) {
        this.user_id = user_id;
        this.goal_tittle = goal_tittle;
        this.description = description;
        this.target_date = target_date;
        this.visibility = visibility;
        this.status = status;
        this.progess = progess;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public String getGoal_tittle() {
        return goal_tittle;
    }

    public void setGoal_tittle(String goal_tittle) {
        this.goal_tittle = goal_tittle;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getTarget_date() {
        return target_date;
    }

    public void setTarget_date(Date target_date) {
        this.target_date = target_date;
    }

    public String getVisibility() {
        return visibility;
    }

    public void setVisibility(String visibility) {
        this.visibility = visibility;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public double getProgess() {
        return progess;
    }

    public void setProgess(double progess) {
        this.progess = progess;
    }
}
