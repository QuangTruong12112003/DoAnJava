package com.example.doancuoiky.Model;

import java.io.Serializable;


import java.util.Timer;

public class Task implements Serializable {
    private int id;
    private int dayplan_id;
    private String tittle;
    private String description;
    private String priority;
    private String status;
    private double progress;
    private String starttime;
    private String endtime;

    public Task(int id, int dayplan_id, String tittle, String description, String priority, String status, double progress, String starttime, String endtime) {
        this.id = id;
        this.dayplan_id = dayplan_id;
        this.tittle = tittle;
        this.description = description;
        this.priority = priority;
        this.status = status;
        this.progress = progress;
        this.starttime = starttime;
        this.endtime = endtime;
    }

    public Task(int dayplan_id, String tittle, String description, String priority, String status, double progress, String starttime, String endtime) {
        this.dayplan_id = dayplan_id;
        this.tittle = tittle;
        this.description = description;
        this.priority = priority;
        this.status = status;
        this.progress = progress;
        this.starttime = starttime;
        this.endtime = endtime;
    }

    public Task() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getDayplan_id() {
        return dayplan_id;
    }

    public void setDayplan_id(int dayplan_id) {
        this.dayplan_id = dayplan_id;
    }

    public String getTittle() {
        return tittle;
    }

    public void setTittle(String tittle) {
        this.tittle = tittle;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public double getProgress() {
        return progress;
    }

    public void setProgress(double progress) {
        this.progress = progress;
    }

    public String getStarttime() {
        return starttime;
    }

    public void setStarttime(String starttime) {
        this.starttime = starttime;
    }

    public String getendtime() {
        return endtime;
    }

    public void setendtime(String endtime) {
        this.endtime = endtime;
    }
}
