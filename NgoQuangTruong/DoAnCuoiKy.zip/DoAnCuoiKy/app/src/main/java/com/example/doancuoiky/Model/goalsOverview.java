package com.example.doancuoiky.Model;

import java.io.Serializable;

public class goalsOverview implements Serializable {
    private int completed_goals;
    private int in_progress_goals;
    private int not_started_goals;
    private int total_goals;


    public goalsOverview(int completed_goals, int in_progress_goals, int not_started_goals, int total_goals) {
        this.completed_goals = completed_goals;
        this.in_progress_goals = in_progress_goals;
        this.not_started_goals = not_started_goals;
        this.total_goals = total_goals;
    }

    public goalsOverview() {
    }

    public int getCompleted_goals() {
        return completed_goals;
    }

    public void setCompleted_goals(int completed_goals) {
        this.completed_goals = completed_goals;
    }

    public int getIn_progress_goals() {
        return in_progress_goals;
    }

    public void setIn_progress_goals(int in_progress_goals) {
        this.in_progress_goals = in_progress_goals;
    }

    public int getNot_started_goals() {
        return not_started_goals;
    }

    public void setNot_started_goals(int not_started_goals) {
        this.not_started_goals = not_started_goals;
    }

    public int getTotal_goals() {
        return total_goals;
    }

    public void setTotal_goals(int total_goals) {
        this.total_goals = total_goals;
    }

    @Override
    public String toString() {
        return "Completed Goals:" + completed_goals + "\n"+
                "In Progress Goals:" + in_progress_goals + "\n"+
                "Not Started Goals:" + not_started_goals + "\n"+
                "Total Goals:" + total_goals;
    }
}
