package com.example.doancuoiky.Model;

import java.io.Serializable;

public class tasksOverview implements Serializable {
    private int pending_tasks;
    private int in_progress_tasks;
    private int completed_tasks;
    private int overdue_tasks;
    private int total_tasks;


    public tasksOverview(int pending_tasks, int in_progress_tasks, int completed_tasks, int overdue_tasks, int total_tasks) {
        this.pending_tasks = pending_tasks;
        this.in_progress_tasks = in_progress_tasks;
        this.completed_tasks = completed_tasks;
        this.overdue_tasks = overdue_tasks;
        this.total_tasks = total_tasks;
    }

    public tasksOverview() {
    }

    public int getPending_tasks() {
        return pending_tasks;
    }

    public void setPending_tasks(int pending_tasks) {
        this.pending_tasks = pending_tasks;
    }

    public int getIn_progress_tasks() {
        return in_progress_tasks;
    }

    public void setIn_progress_tasks(int in_progress_tasks) {
        this.in_progress_tasks = in_progress_tasks;
    }

    public int getCompleted_tasks() {
        return completed_tasks;
    }

    public void setCompleted_tasks(int completed_tasks) {
        this.completed_tasks = completed_tasks;
    }

    public int getOverdue_tasks() {
        return overdue_tasks;
    }

    public void setOverdue_tasks(int overdue_tasks) {
        this.overdue_tasks = overdue_tasks;
    }

    public int getTotal_tasks() {
        return total_tasks;
    }

    public void setTotal_tasks(int total_tasks) {
        this.total_tasks = total_tasks;
    }

    @Override
    public String toString() {
        return "Pending Tasks:" + pending_tasks + "\n"+
                "In progress tasks: " + in_progress_tasks + "\n"+
                "Completed tasks: " + completed_tasks +"\n"+
                "Overdue tasks: " + overdue_tasks +"\n"+
                "Total_tasks:" + total_tasks ;
    }
}
