package com.example.doancuoiky.Network;

import android.util.Log;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.example.doancuoiky.Connect.Connect;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class UserNetworkManager {

    public interface UserCheckCallback {
        void onCheckCompleted(boolean exists);
    }

    public interface UserRegisterCallback {
        void onRegisterCompleted(String result);
    }



    public static void checkUserExists(RequestQueue requestQueue, String email, UserCheckCallback callback) {
        String url = Connect.SERVER_POST;

        StringRequest request = new StringRequest(Request.Method.POST, url,
                response -> {
                    try {
                        JSONArray jsonArray = new JSONArray(response);
                        callback.onCheckCompleted(jsonArray.length() > 0);
                    } catch (JSONException e) {
                        Log.e("Volley", "Lỗi xử lý JSON", e);
                        callback.onCheckCompleted(false);
                    }
                },
                error -> {
                    Log.e("Volley", "Lỗi mạng", error);
                    callback.onCheckCompleted(false);
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("action", "getUser");
                params.put("Email", email);
                return params;
            }
        };

        requestQueue.add(request);
    }

    public static void registerUser(RequestQueue requestQueue, String name, String email, String password, UserRegisterCallback callback) {
        String url = Connect.SERVER_POST;

        StringRequest request = new StringRequest(Request.Method.POST, url,
                response -> {
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        boolean success = jsonObject.getBoolean("message");
                        callback.onRegisterCompleted(success ? "Đăng ký thành công" : "Đăng ký thất bại");
                    } catch (JSONException e) {
                        Log.e("Volley", "Lỗi xử lý JSON", e);
                        callback.onRegisterCompleted("Lỗi trong quá trình xử lý");
                    }
                },
                error -> {
                    Log.e("Volley", "Lỗi mạng", error);
                    callback.onRegisterCompleted("Lỗi không xác định");
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("action", "insertUser");
                params.put("Name", name);
                params.put("Email", email);
                params.put("Password", password);
                params.put("Role", "user");
                return params;
            }
        };

        requestQueue.add(request);
    }
}
